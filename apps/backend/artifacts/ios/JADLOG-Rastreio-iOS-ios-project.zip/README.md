# JADLOG Rastreio iOS — Agente Apple iOS (DVIEW)

Este pacote contém o projeto nativo em Swift / SwiftUI para compilação do aplicativo iOS corporativo do **JADLOG Rastreio iOS**.

## Recursos Incluídos:
1. **SwiftUI Nativo** com modo escuro e identidade visual personalizada (Cores e logotipo).
2. **Telemetria Contínua**: Monitoramento de rede (*Wi-Fi / 5G* via `NWPathMonitor`), nível de bateria e latência.
3. **Heartbeat com Servidor Central**: Registro automático no DVIEW (`http://localhost:3000`).
4. **Perfil de Configuração (.mobileconfig)** incluso para distribuição direta Over-The-Air no iPhone/iPad.

## Como Compilar com Xcode:
1. Abra o projeto no Xcode no macOS.
2. Configure sua equipe de desenvolvimento (*Signing & Capabilities*).
3. Selecione o dispositivo iOS ou Simulador e clique em **Run (Cmd + R)**.
4. Para exportar IPA corporativo: **Product -> Archive -> Distribute App (Enterprise / Ad-Hoc)**.
