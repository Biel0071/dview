//
//  JADLOGRastreioiOSApp.swift
//  JADLOGRastreioiOS — Agente DVIEW para Apple iOS
//

import SwiftUI
import Network
import BackgroundTasks

@main
struct JADLOGRastreioiOSApp: App {
    @StateObject private var agent = DViewAgentManager.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(agent)
                .preferredColorScheme(.dark)
        }
    }
}

// MARK: - Gerenciador Central do Agente iOS
class DViewAgentManager: ObservableObject {
    static let shared = DViewAgentManager()

    @Published var isConnected: Bool = false
    @Published var networkType: String = "Wi-Fi"
    @Published var batteryLevel: Int = 100
    @Published var deviceStatus: String = "DISPONÍVEL"

    private let monitor = NWPathMonitor()
    private let serverURL = URL(string: "http://localhost:3000")!

    init() {
        startNetworkMonitoring()
        startBatteryMonitoring()
        connectToServer()
    }

    private func startNetworkMonitoring() {
        monitor.pathUpdateHandler = { path in
            DispatchQueue.main.async {
                if path.usesInterfaceType(.wifi) {
                    self.networkType = "Wi-Fi 5GHz"
                } else if path.usesInterfaceType(.cellular) {
                    self.networkType = "5G / LTE"
                } else {
                    self.networkType = "Ethernet"
                }
            }
        }
        let queue = DispatchQueue(label: "NetworkMonitor")
        monitor.start(queue: queue)
    }

    private func startBatteryMonitoring() {
        UIDevice.current.isBatteryMonitoringEnabled = true
        let level = UIDevice.current.batteryLevel
        self.batteryLevel = level >= 0 ? Int(level * 100) : 100
    }

    func connectToServer() {
        // Envia telemetria e heartbeat periódicos para a API Fastify
        guard let registerUrl = URL(string: "http://localhost:3000/devices/register") else { return }
        var request = URLRequest(url: registerUrl)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let payload: [String: Any] = [
            "id": "ios_" + (UIDevice.current.identifierForVendor?.uuidString.prefix(8) ?? "device"),
            "name": UIDevice.current.name,
            "model": UIDevice.current.model + " (iOS " + UIDevice.current.systemVersion + ")",
            "androidVersion": "iOS " + UIDevice.current.systemVersion,
            "status": "online",
            "battery": self.batteryLevel,
            "networkType": self.networkType.contains("Wi-Fi") ? "wifi" : "4g",
            "networkName": self.networkType,
            "signalStrength": 95,
            "networkSpeed": "120 Mbps",
            "pingMs": 14,
            "isEmulator": false
        ]

        request.httpBody = try? JSONSerialization.data(withJSONObject: payload)
        URLSession.shared.dataTask(with: request) { _, response, _ in
            if let http = response as? HTTPURLResponse, http.statusCode == 200 {
                DispatchQueue.main.async {
                    self.isConnected = true
                }
            }
        }.resume()
    }
}
