//
//  ContentView.swift
//  JADLOGRastreioiOS
//

import SwiftUI

struct ContentView: View {
    @EnvironmentObject var agent: DViewAgentManager
    @State private var loadingProgress: Double = 0.0

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VStack(spacing: 24) {
                Spacer()

                // Badge Oficial da Marca
                HStack(spacing: 12) {
                    Image(systemName: "shippingbox.fill")
                        .font(.system(size: 26))
                        .foregroundColor(Color(hex: "#dc2626"))

                    Text("JADLOG Rastreio iOS")
                        .font(.system(size: 22, weight: .black, design: .rounded))
                        .foregroundColor(.white)
                }
                .padding(.horizontal, 24)
                .padding(.vertical, 14)
                .background(Color(white: 0.12))
                .cornerRadius(16)
                .shadow(color: Color.black.opacity(0.6), radius: 10)

                // Indicador de Carregamento e Status
                VStack(spacing: 12) {
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle(tint: Color.cyan))
                        .scaleEffect(1.4)

                    Text(agent.isConnected ? "Conectado ao DVIEW Central" : "Sincronizando com o Servidor...")
                        .font(.footnote)
                        .foregroundColor(.gray)
                }
                .padding(.top, 20)

                // Card de Telemetria Operacional
                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        Text("TELEMETRIA OPERACIONAL")
                            .font(.caption2)
                            .fontWeight(.bold)
                            .foregroundColor(.gray)
                        Spacer()
                        Circle()
                            .fill(agent.isConnected ? Color.green : Color.orange)
                            .frame(width: 8, height: 8)
                        Text(agent.isConnected ? "DISPONÍVEL" : "CONECTANDO")
                            .font(.caption2)
                            .fontWeight(.heavy)
                            .foregroundColor(agent.isConnected ? .green : .orange)
                    }

                    Divider().background(Color.gray.opacity(0.3))

                    HStack {
                        Label(agent.networkType, systemImage: "wifi")
                            .font(.caption)
                            .foregroundColor(.white)
                        Spacer()
                        Label("\(agent.batteryLevel)%", systemImage: "battery.100")
                            .font(.caption)
                            .foregroundColor(.white)
                    }
                }
                .padding()
                .background(Color(white: 0.08))
                .cornerRadius(12)
                .padding(.horizontal, 32)
                .padding(.top, 16)

                Spacer()

                Text("© 2026 JADLOG Rastreio iOS. All Rights Reserved.")
                    .font(.caption2)
                    .foregroundColor(Color.gray.opacity(0.6))
                    .padding(.bottom, 20)
            }
        }
    }
}

// Extensão utilitária para Cores Hex
extension Color {
    init(hex: String) {
        let clean = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: clean).scanHexInt64(&int)
        let r, g, b: UInt64
        switch clean.count {
        case 6:
            (r, g, b) = ((int >> 16) & 0xFF, (int >> 8) & 0xFF, int & 0xFF)
        default:
            (r, g, b) = (220, 38, 38)
        }
        self.init(
            .sRGB,
            red: Double(r) / 255,
            green: Double(g) / 255,
            blue: Double(b) / 255,
            opacity: 1.0
        )
    }
}
